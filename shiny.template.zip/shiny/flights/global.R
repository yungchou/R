library(shiny)

flights <- read.csv(file = "./flights14.csv")