fluidPage(

  titlePanel("Page Title"),

  sidebarLayout(

    sidebarPanel(
      img(src="image1.jpeg", width="100%")
    ),

    mainPanel(
      tags$iframe(src="https://www.youtube.com/embed/gSGWfo1j5ic",
                  width="637", height="478")
    )
  )
)

