library(shiny)
library(dplyr)
library(dygraphs)
library(tidyr)
library(ggplot2)
library(RColorBrewer)
library(xts)

# temp_data <- read.csv(
#   "n:/dataset/timeseries/GlobalLandTemperaturesByCity.csv",
#   header = TRUE)

# require(data.table)
# temp_data <- na.omit(
#   fread('n:/dataset/timeseries/GlobalLandTemperaturesByCity.csv')
# )

#-----------
# SHINY APP
#-----------
ui <- fluidPage(

  titlePanel("This is my Shiny App"),

  fluidRow(

    sidebarLayout(
      sidebarPanel(
        selectizeInput(inputId = "origin",
                       label = "Departure airport",
                       choices = unique(flights[, 'origin'])),
        selectizeInput(inputId = "dest",
                       label = "Arrival airport",
                       choices = unique(flights[, 'dest']))
      ),
    mainPanel(
      fluidRow(
        column(6, plotOutput("count")),
        column(6, plotOutput("delay"))
      ),
      fluidRow(
        column(12, plotOutput("dygraph"))
      )
    ))
  )
)

server <- function(input, output, session) {

  sim_rt_files <- read.csv(
    'N:/code/R/shiny/shiny.iot.base.v2/iot_sample_data.csv',
    header = TRUE)

  source <- sim_rt_files

  df <- na.omit(source) %>%
    select( Timestamp, message ) %>%
    mutate( Timestamp = anytime( as.character(Timestamp) ) ) %>%
    arrange( Timestamp ) %>%
    mutate( message = as.character(message) )

  df1 <- df$message %>% as.tbl_json %>%
    gather_array %>%
    spread_values(
      msgID = jstring("messageId"),
      devID = jstring("deviceId"),
      temperature = jnumber("temperature"),
      humidity = jnumber("humidity")) %>%
    select(devID, temperature, humidity)

  n=100

  iot_time <- df$Timestamp[1:n]
  iot_temp <- df1$temperature[1:n]
  iot_humi <- df1$humidity[1:n]

  ambient <- cbind(iot_temp,iot_humi)
  ambient <- xts(ambient, order.by = iot_time)

  dygraphOutput <- renderDygraph({
    dygraph(ambient,
          main='Simulated Realtime Reading for IoT Stream Data',
          group=ts) %>%
    dySeries("iot_temp", label='Temperature') %>%
    dySeries("iot_humi", axis='y2', label='Humidity') %>%
    dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
    dyAxis("y2", label="Humidity (%)") %>%
    dyOptions( fillGraph=TRUE, fillAlpha=0.5) %>%
    dyHighlight(
      highlightCircleSize=5,
      highlightSeriesBackgroundAlpha=0.2,
      hideOnMouseOut=FALSE) %>%
    dyRoller(rollPeriod=5) %>%
    dyOptions(colors=RColorBrewer::brewer.pal(3, "Dark2")) %>%
    dyRangeSelector(height=20) %>% dyUnzoom() %>%
    dyCrosshair(direction="vertical") %>%
    dyLegend(show = "follow")})

  # Flights-final ===================================
  observe({
    dest <- unique( flights %>% filter(
        flights$origin == input$origin) %>% .$dest)
    updateSelectizeInput(
      session, "dest",
      choices = dest,
      selected = dest[1])
  })

  flights_delay <- reactive({
    flights %>%
      filter(origin == input$origin & dest == input$dest) %>%
      group_by(carrier) %>%
      summarise(
        n = n(),
        departure = mean(dep_delay),
        arrival = mean(arr_delay))
  })

  output$delay <- renderPlot(
    flights_delay() %>%
      gather(key = type, value = delay, departure, arrival) %>%
      ggplot(aes(x = carrier, y = delay, fill = type)) +
      geom_col(position = "dodge") +
      ggtitle("Average delay")
  )

  output$count <- renderPlot(
    flights_delay() %>%
      ggplot(aes(x = carrier, y = n)) +
      geom_col(fill = "lightblue") +
      ggtitle("Number of flights")
  )

}

shinyApp(ui, server)