
function(input, output, session) {

  output$devLocMap<- renderLeaflet({

    leaflet() %>% addTiles() %>%
      setView(-99, 38, 4) %>%
      addMarkers(lng=-99, lat=38,
                 popup="<b>Howdy from</b><br><a href='http://www.haysusa.com/'>Hays, KS</a>")%>%
      addMarkers(lng,lat,label=deviceID,labelOptions=labelOptions(
          noHide = T,textOnly = T,textsize = "16px",offset = c(-5, -10)) )
  })

  output$ts <- renderDygraph({

    dygraph(ambient,
            main='Simulated Realtime Reading for IoT Stream Data',
            group=ts) %>%
      dySeries("iot_temp", label='Temperature') %>%
      dySeries("iot_humi", axis='y2', label='Humidity') %>%
      dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
      dyAxis("y2", label="Humidity (%)") %>%
      dyOptions( fillGraph=TRUE, fillAlpha=0.6) %>%
      dyHighlight(
        highlightCircleSize=5,
        highlightSeriesBackgroundAlpha=0.2,
        hideOnMouseOut=FALSE) %>%
      # dyRoller(rollPeriod=5) %>%
      dyOptions(colors=RColorBrewer::brewer.pal(3, "Set2")) %>%
      dyRangeSelector(height=10) %>% dyUnzoom() %>%
      dyCrosshair(direction="vertical") %>%
      dyLegend(show = "follow")

  })

  output$rp1 <- renderDygraph({

    rp1 <- xts(rp1, order.by = iot_time[1:nrow(rp1)])

    dygraph(rp1,
          main='RP1',
          group=ts) %>%
    dySeries("temperature", label='Temperature') %>%
    dySeries("humidity", axis='y2', label='Humidity') %>%
    dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
    dyAxis("y2", label="Humidity (%)") %>%
    dyOptions( fillGraph=TRUE, fillAlpha=0.6) %>%
    dyHighlight(
      highlightCircleSize=5,
      highlightSeriesBackgroundAlpha=0.2,
      hideOnMouseOut=FALSE) %>%
    # dyRoller(rollPeriod=5) %>%
    dyOptions(colors=RColorBrewer::brewer.pal(3, "Set2")) %>%
    dyRangeSelector(height=10) %>% dyUnzoom() %>%
    dyCrosshair(direction="vertical") %>%
    dyLegend(show = "follow")

  })

  output$rp2 <- renderDygraph({

    rp2 <- xts(rp2, order.by = iot_time[1:nrow(rp2)])

    dygraph(rp2,
            main='RP2',
            group=ts) %>%
      dySeries("temperature", label='Temperature') %>%
      dySeries("humidity", axis='y2', label='Humidity') %>%
      dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
      dyAxis("y2", label="Humidity (%)") %>%
      dyOptions( fillGraph=TRUE, fillAlpha=0.6) %>%
      dyHighlight(
        highlightCircleSize=5,
        highlightSeriesBackgroundAlpha=0.2,
        hideOnMouseOut=FALSE) %>%
      # dyRoller(rollPeriod=5) %>%
      dyOptions(colors=RColorBrewer::brewer.pal(3, "Set2")) %>%
      dyRangeSelector(height=10) %>% dyUnzoom() %>%
      dyCrosshair(direction="vertical") %>%
      dyLegend(show = "follow")
  })

  output$rp3 <- renderDygraph({

    rp3 <- xts(rp3, order.by = iot_time[1:nrow(rp3)])

    dygraph(rp3,
            main='RP3',
            group=ts) %>%
      dySeries("temperature", label='Temperature') %>%
      dySeries("humidity", axis='y2', label='Humidity') %>%
      dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
      dyAxis("y2", label="Humidity (%)") %>%
      dyOptions( fillGraph=TRUE, fillAlpha=0.6) %>%
      dyHighlight(
        highlightCircleSize=5,
        highlightSeriesBackgroundAlpha=0.2,
        hideOnMouseOut=FALSE) %>%
      # dyRoller(rollPeriod=5) %>%
      dyOptions(colors=RColorBrewer::brewer.pal(3, "Set2")) %>%
      dyRangeSelector(height=10) %>% dyUnzoom() %>%
      dyCrosshair(direction="vertical") %>%
      dyLegend(show = "follow")
  })

}
