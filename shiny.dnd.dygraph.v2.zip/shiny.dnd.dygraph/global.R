library(shiny)
library(dplyr)
library(tidyr)
library(ggplot2)
library(dygraphs)
library(xts)
library(anytime)
library(tidyjson)
library(leaflet)
library(reshape2) # for melt

lng=c(-97,-92)
lat=c(32,37)
deviceID=c('rp1','rp2','rp3','rp4', 'rp5')

flights <- read.csv(file = "n:/dataset/flights14.csv")

sim_rt_files <- read.csv('./iot_sample_data.csv',header = TRUE)

s <- sim_rt_files

df <- na.omit(s) %>%
  select( Timestamp, message ) %>%
  mutate( Timestamp = anytime( as.character(Timestamp) ) ) %>%
  arrange( Timestamp ) %>%
  mutate( message = as.character(message) )

df1 <- df$message %>% as.tbl_json %>%
  gather_array %>%
  spread_values(
    msgID = jstring("messageId"),
    devID = jstring("deviceId"),
    temperature = jnumber("temperature"),
    humidity = jnumber("humidity")) %>%
  select(devID, temperature, humidity)

stats <- df1 %>% group_by(devID) %>%
  summarize(meanTemp=mean(temperature),sdTemp=sd(temperature),
            meanHumi=mean(humidity),sdHumi=sd(humidity),
            cor=cor(temperature,humidity))

n=2000

iot_dev  <- df1$devID[1:n]
device <- unique(iot_dev)

iot_time <- df$Timestamp[1:n]

rp1 <- head(df1,n) %>% filter(devID=='rp1') %>% select(-devID)
rp2 <- head(df1,n) %>% filter(devID=='rp2') %>% select(-devID)
rp3 <- head(df1,n) %>% filter(devID=='rp3') %>% select(-devID)

iot_temp <- df1$temperature[1:n]
iot_humi <- df1$humidity[1:n]

ambient <- cbind(iot_temp,iot_humi)
ambient <- xts(ambient, order.by = iot_time)

rp1temp <- rp1$temperature
rp2temp <- rp2$temperature
rp3temp <- rp3$temperature
rp1humi <- rp1$temperature
rp2humi <- rp2$temperature
rp3humi <- rp3$temperature


tempMin <- min(length(rp1temp),length(rp2temp),length(rp3temp))

dftemp <- melt(data.frame(
  rp1=rp1temp[1:tempMin], rp2=rp2temp[1:tempMin], rp3=rp3temp[1:tempMin]))
ggplot(dftemp,aes(x=value, fill=variable)) +
  geom_density(alpha=0.1) + theme_bw()

dfhumi <- melt(data.frame(
  rp1=rp1humi[1:tempMin], rp2=rp2humi[1:tempMin], rp3=rp3humi[1:tempMin]))
ggplot(dfhumi,aes(x=value, fill=variable)) +
  geom_density(alpha=0.1) + theme_bw()

ggplot(dftemp, aes(y=value,x=variable)) + theme_bw() +
  geom_point(aes(col=variable)) +
  geom_jitter(aes(fill=variable)) +
  geom_boxplot(aes(fill=variable), alpha=0.5)
