library(dplyr)
library(ggplot2)
library(shiny)
library(leaflet)
library(mailR)

library(data.table)
#source('credentials.R')

longitude=c(-115,-90,-72,-85,-72)
latitude=c(48,24,43,34,52)
sensorID=c('rp1','rp2','rp3','rp4', 'rp5')


