#------------------------
# SAMPLE DATA GENERATION
#------------------------
longitude=c(-99,-97,-87,-107,-91)
latitude=c(38,32,30,37,41)
sensorID=c('yc1','yc2','yc3','yc4', 'yc5')

i=0
while(i<2000){
  dat=data.frame(
    timestamp=as.numeric(Sys.time()),
    sensorID=sensorID,longitude=longitude,latitude=latitude,
    temperature=rnorm(n=5,mean=60,sd=1))
  write.csv(dat,paste0('iot_',gsub("[^0-9]","",Sys.time()),".csv"),
            row.names = FALSE)
  i=i+1
  Sys.sleep(2)
}

# while(TRUE){
#   dat=data.frame(timestamp=as.numeric(Sys.time()),sensorID=sensorID[1:5],longitude=longitude[1:5],latitude=latitude[1:5],
#                  temperature=rnorm(n=5,mean=30,sd=1))
#   write.csv(dat,paste0('iot_',gsub("[^0-9]","",Sys.time()),".csv"),
#             row.names = FALSE)
#   Sys.sleep(2)
# }