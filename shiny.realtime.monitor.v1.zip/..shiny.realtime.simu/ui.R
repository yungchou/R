library(shinythemes)

shinyUI(

  fluidPage(
    theme = shinytheme("flatly"),
    navbarPage("IoT",
               tabPanel("Demo"),
               tabPanel("Data Analytics"),
               tabPanel("More Plots"),
               tabPanel("Table"),
               tabPanel("Summary")),
               #    tabPanel("Yung's Blog"),
#    tags$h2("Realtime IoT Data Stream", style="text-align:center"),

    fluidRow( div(style='height=200px'),
      column( width=4, leafletOutput("myleaflet") ),
      column( width=8,
              plotOutput("timeseries_all"),
              column(width=6, offset=5, br(), br(), textOutput("Too_High")),
              column(width=6, offset=5,textOutput("Failed_Sensors"))
      )
    )

  )
)