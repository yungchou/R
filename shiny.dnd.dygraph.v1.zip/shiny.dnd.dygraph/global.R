library(shiny)
library(dplyr)
library(tidyr)
library(ggplot2)
library(dygraphs)
library(xts)
library(anytime)
library(tidyjson)

flights <- read.csv(file = "n:/dataset/flights14.csv")

sim_rt_files <- read.csv(
  'N:/code/R/shiny/shiny.iot.base.v2/iot_sample_data.csv',
  header = TRUE)

s <- sim_rt_files

df <- na.omit(s) %>%
  select( Timestamp, message ) %>%
  mutate( Timestamp = anytime( as.character(Timestamp) ) ) %>%
  arrange( Timestamp ) %>%
  mutate( message = as.character(message) )

df1 <- df$message %>% as.tbl_json %>%
  gather_array %>%
  spread_values(
    msgID = jstring("messageId"),
    devID = jstring("deviceId"),
    temperature = jnumber("temperature"),
    humidity = jnumber("humidity")) %>%
  select(devID, temperature, humidity)

n=100

iot_dev  <- df1$devID[1:n]
device <- unique(iot_dev)

iot_time <- df$Timestamp[1:n]
iot_temp <- df1$temperature[1:n]
iot_humi <- df1$humidity[1:n]

ambient <- cbind(iot_temp,iot_humi)
ambient <- xts(ambient, order.by = iot_time)
