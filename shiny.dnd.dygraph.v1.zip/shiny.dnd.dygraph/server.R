
function(input, output, session) {

  output$dygraph <- renderDygraph({

    dygraph(ambient,
            main='Simulated Realtime Reading for IoT Stream Data',
            group=ts) %>%
      dySeries("iot_temp", label='Temperature') %>%
      dySeries("iot_humi", axis='y2', label='Humidity') %>%
      dyAxis("y",  label="Temperature (C)", independentTicks=TRUE) %>%
      dyAxis("y2", label="Humidity (%)") %>%
      dyOptions( fillGraph=TRUE, fillAlpha=0.5) %>%
      dyHighlight(
        highlightCircleSize=5,
        highlightSeriesBackgroundAlpha=0.2,
        hideOnMouseOut=FALSE) %>%
      dyRoller(rollPeriod=5) %>%
      dyOptions(colors=RColorBrewer::brewer.pal(3, "Dark2")) %>%
      dyRangeSelector(height=20) %>% dyUnzoom() %>%
      dyCrosshair(direction="vertical") %>%
      dyLegend(show = "follow")

  })

  observe({
    dest <- unique(flights %>%
                     filter(flights$origin == input$origin) %>%
                     .$dest)
    updateSelectizeInput(
      session, "dest",
      choices = dest,
      selected = dest[1])
  })

  flights_delay <- reactive({
    flights %>%
      filter(origin == input$origin & dest == input$dest) %>%
      group_by(carrier) %>%
      summarise(n = n(),
                departure = mean(dep_delay),
                arrival = mean(arr_delay))
  })

  output$delay <- renderPlot(
    flights_delay() %>%
      gather(key = type, value = delay, departure, arrival) %>%
      ggplot(aes(x = carrier, y = delay, fill = type)) +
      geom_col(position = "dodge") +
      ggtitle("Average delay")
  )

  output$count <- renderPlot(
    flights_delay() %>%
      ggplot(aes(x = carrier, y = n)) +
      geom_col(fill = "lightblue") +
      ggtitle("Number of flights")
  )
}